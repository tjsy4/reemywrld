var config = {
    'apiKey':'AIzaSyD4ekC5ni2IIW6sej-YrinAidUgdFBGv98',
    'authDomain':'bcjdk-7cee7.firebaseapp.com',
    'databaseURL':'https://bcjdk-7cee7.firebaseio.com',
    'projectId':'bcjdk-7cee7',
    'appId':'1:519513107135:web:da5914af726784cc0eb40a',
    'storageBucket':'bcjdk-7cee7.appspot.com',
    'messagingSenderId':'519513107135' 
};